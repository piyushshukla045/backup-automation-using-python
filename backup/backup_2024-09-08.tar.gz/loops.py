list = ["AWS","AZURE","GCP","CLOUD"]
print(list)

list.append("google cloud")
print(list)

list.insert(1,"alibaba")
print(list)


