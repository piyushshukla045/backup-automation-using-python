import os #importing os libraries into code

print(os.system("dir"))

import os command = "uptime" # load avg command = "date" # 
def check_cpu(command): # defining a function 
    print(os.system(command)) def check_date(command): # defining a function prin